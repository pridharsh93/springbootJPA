package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Account;

public interface IAccountDao {
	public List<Account> getAllAccounts();
	
	public Account findAccountById(int accountNo);
	
	public List<Account> deleteAccount(int accountNo);
	
	
	public List<Account> createAccount(Account account);
	
	
	
}
